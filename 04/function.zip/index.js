console.log('Loading function');

exports.handler = async (event, context) => {
    //console.log('Received event:', JSON.stringify(event, null, 2));
    console.log('Inside the sample function');
    console.log("hello")
    console.log("hello2");
    return event.key1;  // Echo back the first key value
    // throw new Error('Something went wrong');
};
